import streamlit as st
import pandas as pd
import pickle

st.set_page_config(
    page_title="Big Mart Sales Prediction",
    page_icon="🛒",
    layout="wide"
)

# Load trained model
try:
    with open("big_mart_sales_model.pkl", "rb") as file:
        model = pickle.load(file)
except FileNotFoundError:
    st.error("big_mart_sales_model.pkl not found. Please keep app.py and the .pkl file in the same folder.")
    st.stop()

st.title("🛒 Big Mart Sales Prediction")
st.write("Predict the expected sales of a product at a Big Mart outlet.")

st.divider()

col1, col2 = st.columns(2)

with col1:
    st.subheader("🛍️ Product Information")

    item_identifier = st.text_input("Item Identifier", "FDA15")

    item_weight = st.number_input(
        "Item Weight",
        min_value=0.0,
        value=12.0,
        step=0.1
    )

    item_fat_content = st.selectbox(
        "Item Fat Content",
        ["Low Fat", "Regular"]
    )

    item_visibility = st.number_input(
        "Item Visibility",
        min_value=0.0,
        max_value=1.0,
        value=0.05,
        step=0.01
    )

    item_type = st.selectbox(
        "Item Type",
        [
            "Baking Goods",
            "Breads",
            "Breakfast",
            "Canned",
            "Dairy",
            "Frozen Foods",
            "Fruits and Vegetables",
            "Hard Drinks",
            "Health and Hygiene",
            "Household",
            "Meat",
            "Others",
            "Seafood",
            "Snack Foods",
            "Soft Drinks",
            "Starchy Foods"
        ]
    )

    item_mrp = st.number_input(
        "Item MRP",
        min_value=0.0,
        value=150.0,
        step=1.0
    )

with col2:
    st.subheader("🏪 Outlet Information")

    outlet_identifier = st.selectbox(
        "Outlet Identifier",
        [
            "OUT010", "OUT013", "OUT017", "OUT018", "OUT019",
            "OUT027", "OUT035", "OUT045", "OUT046", "OUT049"
        ]
    )

    outlet_establishment_year = st.number_input(
        "Outlet Establishment Year",
        min_value=1900,
        max_value=2026,
        value=2000,
        step=1
    )

    outlet_size = st.selectbox(
        "Outlet Size",
        ["Small", "Medium", "High"]
    )

    outlet_location_type = st.selectbox(
        "Outlet Location Type",
        ["Tier 1", "Tier 2", "Tier 3"]
    )

    outlet_type = st.selectbox(
        "Outlet Type",
        [
            "Grocery Store",
            "Supermarket Type1",
            "Supermarket Type2",
            "Supermarket Type3"
        ]
    )

st.divider()

if st.button("🔮 Predict Sales", use_container_width=True, type="primary"):

    input_data = pd.DataFrame({
        "Item_Identifier": [item_identifier],
        "Item_Weight": [item_weight],
        "Item_Fat_Content": [item_fat_content],
        "Item_Visibility": [item_visibility],
        "Item_Type": [item_type],
        "Item_MRP": [item_mrp],
        "Outlet_Identifier": [outlet_identifier],
        "Outlet_Establishment_Year": [outlet_establishment_year],
        "Outlet_Size": [outlet_size],
        "Outlet_Location_Type": [outlet_location_type],
        "Outlet_Type": [outlet_type]
    })

    try:
        prediction = model.predict(input_data)[0]

        st.success("✅ Prediction completed successfully!")

        st.metric(
            "Estimated Item Outlet Sales",
            f"₹ {prediction:,.2f}"
        )

        st.subheader("📊 Prediction Details")
        st.dataframe(input_data, use_container_width=True)

    except Exception as e:
        st.error("Prediction failed.")
        st.exception(e)

with st.sidebar:
    st.header("🛒 Big Mart Sales")
    st.write("Machine Learning sales prediction application.")
    st.divider()
    st.write("**Model:** Random Forest Regressor")
    st.write("**Target:** Item Outlet Sales")

st.divider()
st.caption("Big Mart Sales Prediction | Machine Learning Project")
